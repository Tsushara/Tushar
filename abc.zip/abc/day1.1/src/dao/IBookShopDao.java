package dao;

import pojos.Customer;

public interface IBookShopDao {
	//user validation
	Customer validateCustomer(String email,String pwd) throws Exception;
}
