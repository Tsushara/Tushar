package dao;

import java.sql.*;
import pojos.Customer;
import utils.DBUtils;

public class BookShoDaoImpl implements IBookShopDao {
	private Connection cn;
	private PreparedStatement pst1;

	// constr
	public BookShoDaoImpl() throws Exception {
		// get cn from DBUtils
		cn = DBUtils.fetchConnection();
		// pst1
		pst1 = cn.prepareStatement("select * from my_customers where email=? and password=?");
		System.out.println("dao created...");
	}

	// clean up
	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		if (cn != null)
			cn.close();
		System.out.println("dao cleaned up...");
	}

	@Override
	public Customer validateCustomer(String email, String pwd) throws Exception {
		// set IN params
		pst1.setString(1, email);
		pst1.setString(2, pwd);
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next())
				return new Customer(rst.getInt(1), rst.getDouble(2), rst.getString(3), email, pwd, rst.getDate(6),
						rst.getString(7));
		}
		return null;
	}

}
